export default interface ISettings {
  targetFolder: string;
  deleteSourceFiles: boolean;
  ignoreNonMediaFiles: boolean;
  outputDirectory: string;
}
