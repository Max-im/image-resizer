export type EventTypes =
  | 'select.folder'
  | 'found.files'
  | 'compress.start'
  | 'compress.completed'
  | 'compress.error'
  | 'compress.cancel'
  | 'compress.cancelled'
  | 'compress.exception'
  | 'compress.file';
