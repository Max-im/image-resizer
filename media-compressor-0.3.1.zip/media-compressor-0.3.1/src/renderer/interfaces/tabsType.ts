export type tabsType = 'photo' | 'video';
